Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("localhost:1080", 
		"URL=http://localhost:1080/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_form("login.pl", 
		"Snapshot=t29.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=0", ENDITEM, 
		"Name=login.y", "Value=0", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t30.inf", 
		EXTRARES, 
		"Url=../WebTours/classes/FormDateUpdate.class", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(13);

	web_submit_form("reservations.pl", 
		"Snapshot=t31.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=09/14/2021", ENDITEM, 
		"Name=arrive", "Value=London", ENDITEM, 
		"Name=returnDate", "Value=09/15/2021", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=55", ENDITEM, 
		"Name=findFlights.y", "Value=7", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_2", 
		"Snapshot=t32.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=020;338;09/14/2021", ENDITEM, 
		"Name=reserveFlights.x", "Value=70", ENDITEM, 
		"Name=reserveFlights.y", "Value=16", ENDITEM, 
		LAST);

	lr_think_time(13);

	web_submit_form("reservations.pl_3", 
		"Snapshot=t33.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=Lenin", ENDITEM, 
		"Name=address2", "Value=Moscow", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=12345678", ENDITEM, 
		"Name=expDate", "Value=123", ENDITEM, 
		"Name=saveCC", "Value=on", ENDITEM, 
		"Name=buyFlights.x", "Value=20", ENDITEM, 
		"Name=buyFlights.y", "Value=7", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t34.inf", 
		LAST);

	return 0;
}